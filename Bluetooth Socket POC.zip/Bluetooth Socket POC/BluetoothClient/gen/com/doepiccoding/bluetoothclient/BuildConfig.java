/** Automatically generated file. DO NOT MODIFY */
package com.doepiccoding.bluetoothclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}