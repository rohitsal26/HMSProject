package com.doepiccoding.bluetoothclient;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.doepiccoding.bluetoothserver.FileData;

public class ClientActivity extends Activity {

	private Button btn_scan;
	private ArrayAdapter<String> newDevicelistArrayAdapter;
	private ListView new_devices_list;
	private BluetoothAdapter mBluetoothAdapter;
	private static final int REQUEST_ENABLE_BT = 1;
	private BluetoothSocket socket;
	private InputStream is;
	private OutputStream os;
	private BluetoothDevice remoteDevice;
	private String desinationDeviceName;
	private BroadcastReceiver discoveryResult = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			android.util.Log.e("TrackingFlow", "WWWTTTFFF");
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_client);
		btn_scan = (Button) this.findViewById(R.id.btn_scan);

		newDevicelistArrayAdapter = new ArrayAdapter<String>(this,
				R.layout.device_name);
		new_devices_list = (ListView) findViewById(R.id.new_devices_list);
		new_devices_list.setAdapter(newDevicelistArrayAdapter);

		btn_scan.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

				newDevicelistArrayAdapter.clear();

				mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
				if (mBluetoothAdapter == null) {
					Toast.makeText(ClientActivity.this, "No support bluetooth",
							Toast.LENGTH_SHORT).show();
					finish();
					return;
				} else if (!mBluetoothAdapter.isEnabled()) {
					Intent enableBTIntent = new Intent(
							BluetoothAdapter.ACTION_REQUEST_ENABLE);
					startActivityForResult(enableBTIntent, REQUEST_ENABLE_BT);
				}

				Set<BluetoothDevice> lstBluetooth = mBluetoothAdapter
						.getBondedDevices();
				for (BluetoothDevice bd : lstBluetooth) {
					newDevicelistArrayAdapter.add(bd.getAddress() + "-"
							+ bd.getName());
				}

				IntentFilter filter = new IntentFilter(
						BluetoothDevice.ACTION_FOUND);
				registerReceiver(discoveryResult, filter);
				mBluetoothAdapter.startDiscovery();

			}
		});

		new_devices_list.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				
				if (socket != null) {
					try {
						if(is !=null){
							is.close();
						}						
						socket.close();
					} catch (Exception e) {
					}
				}
				
				String[] strArr = ((TextView) arg1).getText().toString()
						.split("-", 2);
				desinationDeviceName = strArr[0];
				
				System.out.println("desinationDeviceName "+desinationDeviceName);
				
				new ConnectBluetoothDeviceAsyncTask().execute(desinationDeviceName);
				
			}
		});

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		try {
			unregisterReceiver(discoveryResult);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (socket != null) {
			try {
				is.close();
				socket.close();
			} catch (Exception e) {
			}
		}
	}
	
	
	private class ConnectBluetoothDeviceAsyncTask extends AsyncTask<String, Void, Boolean>{

		@Override
		protected Boolean doInBackground(String... params) {
	
			mBluetoothAdapter.cancelDiscovery();
			
			try {
				remoteDevice = mBluetoothAdapter.getRemoteDevice(params[0]);
				UUID uuid = UUID
						.fromString("4e5d48e0-75df-11e3-981f-0800200c9a66");

				socket = remoteDevice.createRfcommSocketToServiceRecord(uuid);
				socket.connect();
			} catch (Exception e) {				
				System.out.println("Error " + e);
				return false;
			}
			
			System.out.println("Connected..."+socket.isConnected());
			return socket.isConnected();
		}
		
		@Override
		protected void onPostExecute(Boolean result) {
			super.onPostExecute(result);
			
			if(result){
				Toast.makeText(ClientActivity.this, "Device "+desinationDeviceName+" connected successfully for data transfer....", Toast.LENGTH_SHORT).show();
				
				InputStream tmpIn = null;
				try {
					tmpIn = socket.getInputStream();
				} catch (IOException e) {
					System.out.println("Error..." + e);
				}
				
				is = tmpIn;
				
				AcceptData acceptData = new AcceptData();
				acceptData.execute();
				
			}else{
				Toast.makeText(ClientActivity.this, "Device "+desinationDeviceName+" is not found...", Toast.LENGTH_SHORT).show();
			}
			
		}
		
	}

	private class AcceptData extends AsyncTask<Void, Void, List<FileData>> {

	
		@Override
		protected List<FileData> doInBackground(Void... params) {

			List<FileData> data = readChunk(1024 * 8);

			if (data != null) {

				File sdCard = Environment.getExternalStorageDirectory();
				File dir = new File(sdCard.getAbsolutePath() + "/Target");
				dir.mkdirs();

				int i = 1;
				for (FileData fileData : data) {

					File file = new File(dir, fileData.getFilename());
					
					System.out.println("File Name " + fileData.getFilename());
					FileOutputStream fos;
					try {
						fos = new FileOutputStream(file);
						fos.write(fileData.getData());
						fos.flush();
						fos.close();
					} catch (FileNotFoundException e) {
						System.out.println("Error 1 " + e);
						e.printStackTrace();
					} catch (IOException e) {
						System.out.println("Error 2 " + e);
						e.printStackTrace();
					}

				}
			}
			return data;

		}

		@SuppressWarnings("unchecked")
		public List<FileData> toObject(byte[] bytes) throws IOException,
				ClassNotFoundException {
			List<FileData> obj = null;
			ByteArrayInputStream bis = null;
			ObjectInputStream ois = null;
			try {
				bis = new ByteArrayInputStream(bytes);
				ois = new ObjectInputStream(bis);
				obj = (List<FileData>) ois.readObject();
			} finally {
				if (bis != null) {
					bis.close();
				}
				if (ois != null) {
					ois.close();
				}
				if (socket != null) {
					try {
						is.close();
					} catch (IOException e) {
						//
					}
				}
			}
			return obj;
		}

		public List<FileData> readChunk(int chunksize) {

			byte[] resultBuff = new byte[0];
			byte[] buff = new byte[chunksize];
			int k = -1;
			String fileEnd = "";
			while (true) {
				try {
					k = is.read(buff, 0, buff.length);
					byte[] tbuff = new byte[resultBuff.length + k]; 
					System.arraycopy(resultBuff, 0, tbuff, 0, resultBuff.length); 
					System.arraycopy(buff, 0, tbuff, resultBuff.length, k); 
					resultBuff = tbuff; 
					StringBuilder endFile = new StringBuilder();
					endFile.append((char) resultBuff[resultBuff.length - 4]);
					endFile.append((char) resultBuff[resultBuff.length - 3]);
					endFile.append((char) resultBuff[resultBuff.length - 2]);
					endFile.append((char) resultBuff[resultBuff.length - 1]);

					System.out.println("----" + endFile);

					if ("done".equals(endFile.toString().trim())) {
						fileEnd = fileEnd.toString();
						System.out.println("End--------");
						break;
					}

				} catch (IOException ie) {
					System.out.println("Error while reading file--------" + ie);
				}

			}

			List<FileData> data = Collections.emptyList();
			try {
				data = (List<FileData>) toObject(resultBuff);
			} catch (ClassNotFoundException e) {
				System.out.println("Error while converting object back--------"
						+ e);
			} catch (IOException e) {
				System.out.println("Error while reading file--------" + e);
			}

			System.out.println("End--------" + data.size());
			return data;

		}

		@Override
		protected void onPostExecute(List<FileData> result) {
			super.onPostExecute(result);

			 gridView = (GridView) findViewById(R.id.gridView);
		     gridAdapter = new GridViewAdapter(ClientActivity.this, R.layout.grid_item_layout, result);
		     gridView.setAdapter(gridAdapter);
		     if (socket != null) {
					try {						
						is.close();
						socket.close();
					} catch (IOException e) {
						System.out.println("Error while closing socket...");
					}
				}		    
		        
		}

	}
	
	 private GridView gridView;
	    private GridViewAdapter gridAdapter;


}
