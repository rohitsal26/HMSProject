package com.doepiccoding.bluetoothclient;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.doepiccoding.bluetoothserver.FileData;

public class GridViewAdapter extends ArrayAdapter{
	private Context context;
	private int layoutResourceId;
	private List<FileData> data = new ArrayList<FileData>();

	public GridViewAdapter(Context context, int layoutResourceId, List<FileData> data) {
		super(context, layoutResourceId, data);
		this.layoutResourceId = layoutResourceId;
		this.context = context;
		this.data = data;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View row = convertView;
		ViewHolder holder = null;

		if (row == null) {
			LayoutInflater inflater = ((Activity) context).getLayoutInflater();
			row = inflater.inflate(layoutResourceId, parent, false);
			holder = new ViewHolder();
			holder.imageTitle = (TextView) row.findViewById(R.id.text);
			holder.image = (ImageView) row.findViewById(R.id.image);
			row.setTag(holder);
		} else {
			holder = (ViewHolder) row.getTag();
		}

		FileData item = data.get(position);
		holder.imageTitle.setText(item.getFilename());
		
		int i = item.getFilename().lastIndexOf('.');
		if (i > 0) {
			item.setFileExtension(item.getFilename().substring(i+1));
		}
		
		if("jpg".equals(item.getFileExtension().trim())){
			Bitmap bm = BitmapFactory.decodeByteArray(item.getData(), 0,
					item.getData().length);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			bm.compress(Bitmap.CompressFormat.JPEG, 100, baos);
			byte[] b = baos.toByteArray();
			Bitmap bm1 = BitmapFactory.decodeByteArray(b, 0, b.length);
			holder.image.setImageBitmap(bm1);
		}else if("html".equals(item.getFileExtension().trim())){
			holder.image.setBackgroundResource(R.drawable.html_logo);
		}
		
		
		return row;
	}

	static class ViewHolder {
		TextView imageTitle;
		ImageView image;
	}
}
