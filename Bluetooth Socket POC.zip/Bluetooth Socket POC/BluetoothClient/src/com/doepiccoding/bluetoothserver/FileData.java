package com.doepiccoding.bluetoothserver;

import java.io.Serializable;

public class FileData implements Serializable {
	
	private static final long serialVersionUID = 7526472295622776147L;
	
	private String filename;
	private byte[] data;
	private String fileExtension;

	

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

}
