package com.doepiccoding.bluetoothserver;

import java.io.ByteArrayOutputStream;
import java.util.Arrays;
import java.util.List;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class FileListAdapter extends BaseAdapter {

	private List<FileData> lstFiles;
	private Context context;

	public List<FileData> getLstFiles() {
		return lstFiles;
	}

	public void setLstFiles(List<FileData> lstFiles) {
		this.lstFiles = lstFiles;
	}

	public FileListAdapter(List<FileData> lstFiles, Context context) {
		this.lstFiles = lstFiles;
		this.context = context;
	}

	@SuppressLint("ViewHolder")
	public View getView(int position, View convertView, ViewGroup parent) {

		ViewHolder holder;

		if (convertView == null) {

			/****** Inflate tabitem.xml file for each row ( Defined below ) *******/
			LayoutInflater inflater = (LayoutInflater) context
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = inflater
					.inflate(R.layout.lst_file_row, parent, false);

			/****** View Holder Object to contain tabitem.xml file elements ******/

			holder = new ViewHolder();

			holder.txtFileName = (TextView) convertView
					.findViewById(R.id.txtFileName);
			holder.imageView = (ImageView) convertView.findViewById(R.id.icon);
			holder.txtFileExtension = (TextView) convertView
					.findViewById(R.id.txtFileExtension);
			holder.txtFileSize = (TextView) convertView
					.findViewById(R.id.txtFileSize);
			FileData fileData = (FileData) getItem(position);

			holder.txtFileName.setText("File Name: " + fileData.getFilename());
			holder.txtFileExtension.setText("File Extension: "
					+ fileData.getFileExtension());
			holder.txtFileSize.setText("File Size: "
					+ (fileData.getData().length / 1024) + " KB");
			if("jpg".equals(fileData.getFileExtension().trim())){
				Bitmap bm = BitmapFactory.decodeByteArray(fileData.getData(), 0,
						fileData.getData().length);
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				bm.compress(Bitmap.CompressFormat.JPEG, 100, baos);
				byte[] b = baos.toByteArray();
				Bitmap bm1 = BitmapFactory.decodeByteArray(b, 0, b.length);
				holder.imageView.setImageBitmap(bm1);
			}else if("html".equals(fileData.getFileExtension().trim())){
				//holder.imageView.setBackgroundResource(R.drawable.html_logo);
			}
				
			

		}

		return convertView;

	}

	public static class ViewHolder {

		public TextView txtFileName;
		public ImageView imageView;
		public TextView txtFileExtension;
		public TextView txtFileSize;

	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return lstFiles.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return lstFiles.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	};
}
