package com.doepiccoding.bluetoothserver;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class EncryptDecrpyFile {
	public EncryptDecrpyFile() {
		try {
			/**
			 * Create a Blowfish key
			 */
			keyGenerator = KeyGenerator.getInstance("Blowfish");
			secretKey = keyGenerator.generateKey();

			/**
			 * Create an instance of cipher mentioning the name of algorithm -
			 * Blowfish
			 */
			cipher = Cipher.getInstance("Blowfish");
		} catch (NoSuchPaddingException ex) {
			System.out.println(ex);
		} catch (NoSuchAlgorithmException ex) {
			System.out.println(ex);
		}
	}

	KeyGenerator keyGenerator = null;
	SecretKey secretKey = null;
	Cipher cipher = null;

	/*public static void main(String[] args) {
		String fileToEncrypt = "Desert.jpg";
		String encryptedFile = "testing1.jpg";
		String decryptedFile = "testing2.jpg";
		String directoryPath = "D:/encrypt/";
		EncryptDecrpyFile encryptFile = new EncryptDecrpyFile();
		System.out.println("Starting Encryption...");
		encryptFile.encrypt(directoryPath + fileToEncrypt, directoryPath
				+ encryptedFile);
		System.out.println("Encryption completed...");

		System.out.println("Starting Decryption...");
		encryptFile.decrypt(directoryPath + encryptedFile, directoryPath
				+ decryptedFile);
		System.out.println("Decryption completed...");

	}*/

	 public void encrypt(String srcPath, String destPath) {
		File rawFile = new File(srcPath);
		File encryptedFile = new File(destPath);
		InputStream inStream = null;
		OutputStream outStream = null;
		System.out.println("dirPath"+ srcPath);
		try {
			/**
			 * Initialize the cipher for encryption
			 */
			cipher.init(Cipher.ENCRYPT_MODE, secretKey);
			/**
			 * Initialize input and output streams
			 */
			inStream = new FileInputStream(rawFile);
			outStream = new FileOutputStream(encryptedFile);
			byte[] buffer = new byte[1024];
			int len;
			while ((len = inStream.read(buffer)) > 0) {
				outStream.write(cipher.update(buffer, 0, len));
				outStream.flush();
			}
			outStream.write(cipher.doFinal());
			inStream.close();
			outStream.close();
			System.out.println("dirPath"+ srcPath+len);
			System.out.println("dirPath"+ destPath+len);
		} catch (IllegalBlockSizeException ex) {
			System.out.println("dirPath"+ex);
		} catch (BadPaddingException ex) {
			System.out.println("dirPath"+ex);
		} catch (InvalidKeyException ex) {
			System.out.println("dirPath"+ex);
		} catch (FileNotFoundException ex) {
			System.out.println("dirPath"+ex);
		} catch (IOException ex) {
			System.out.println("dirPath"+ex);
		}
	}

	/**
	 * 
	 * @param srcPath
	 * @param destPath
	 * 
	 *            Decrypts the file in srcPath and creates a file in destPath
	 */
	public void decrypt(String srcPath, String destPath) {
		File encryptedFile = new File(srcPath);
		File decryptedFile = new File(destPath);
		InputStream inStream = null;
		OutputStream outStream = null;
		try {
			/**
			 * Initialize the cipher for decryption
			 */
			cipher.init(Cipher.DECRYPT_MODE, secretKey);
			/**
			 * Initialize input and output streams
			 */
			inStream = new FileInputStream(encryptedFile);
			outStream = new FileOutputStream(decryptedFile);
			byte[] buffer = new byte[1024];
			int len;
			while ((len = inStream.read(buffer)) > 0) {
				outStream.write(cipher.update(buffer, 0, len));
				outStream.flush();
			}
			outStream.write(cipher.doFinal());
			inStream.close();
			outStream.close();
		} catch (IllegalBlockSizeException ex) {
			System.out.println(ex);
		} catch (BadPaddingException ex) {
			System.out.println(ex);
		} catch (InvalidKeyException ex) {
			System.out.println(ex);
		} catch (FileNotFoundException ex) {
			System.out.println(ex);
		} catch (IOException ex) {
			System.out.println(ex);
		}
	}
	
	public byte[] decryptFileData(String srcPath) {
        File encryptedFile = new File(srcPath);
        InputStream inStream = null;
        byte[] bytes = null;
        try {
            /**
             * Initialize the cipher for decryption
             */
            cipher.init(Cipher.DECRYPT_MODE, secretKey);
            /**
             * Initialize input and output streams
             */
            inStream = new FileInputStream(encryptedFile);

            CipherInputStream cin=new CipherInputStream(inStream, cipher);

            bytes = new byte[(int) encryptedFile.length()];
            BufferedInputStream bis = new BufferedInputStream(cin);
            bis.read(bytes, 0, bytes.length);
            bis.close();

        }  catch (InvalidKeyException ex) {
            System.out.println(ex);
        } catch (FileNotFoundException ex) {
            System.out.println(ex);
        } catch (IOException ex) {
            System.out.println(ex);
        }

        return bytes;
    }
}
