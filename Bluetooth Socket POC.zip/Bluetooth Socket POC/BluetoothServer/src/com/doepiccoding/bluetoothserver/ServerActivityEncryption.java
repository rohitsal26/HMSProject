package com.doepiccoding.bluetoothserver;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

public class ServerActivityEncryption extends Activity {

	private static final int DISCOVERABLE_REQUEST_CODE = 0x1;
	private BluetoothSocket socket;

	private OutputStream os = null;
	private Button sendButton;
	private ListView lstFiles;
	List<FileData> lstFileData;
	private ProgressBar progressBar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_server);
		
		sendButton = (Button) findViewById(R.id.send);
		lstFiles = (ListView) findViewById(R.id.lstFiles);
		progressBar = (ProgressBar) findViewById(R.id.logout_progressBar);
		progressBar.setClickable(false);
		
		lstFileData = new ArrayList<FileData>();
		//--------------
		File[] file = Environment.getExternalStoragePublicDirectory(
				Environment.DIRECTORY_DOWNLOADS).listFiles();
		
		File sdCard = Environment.getExternalStorageDirectory();
		File dirPath  = new File(sdCard.getAbsolutePath()+"/R");
		if(!dirPath.exists()){
			dirPath.mkdir();
		}
				
		EncryptDecrpyFile decrpyFile=new EncryptDecrpyFile();
		
		for(File f : file){
			String path = dirPath.getAbsolutePath()+"/"+f.getName();
			decrpyFile.encrypt(f.getAbsolutePath(), path);
			f.delete();
		}
		//------------
		//File[] file = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).listFiles();

		/*for (File f : file) {
			try {
				byte[] bytes = new byte[(int) f.length()];
				BufferedInputStream bis;
				bis = new BufferedInputStream(new FileInputStream(f));
				bis.read(bytes, 0, bytes.length);
				System.out.println("Data " + bytes.length);
				FileData data = new FileData();
				data.setData(bytes);
				data.setFilename(f.getName());
				int i = f.getName().lastIndexOf('.');
				if (i > 0) {
					data.setFileExtension(f.getName().substring(i+1));
				}
				
				lstFileData.add(data);
				bis.close();
			} catch (Exception e) {
				System.out.println("Error While reading file ..." + e);
			}
		}*/
		//-----------------------------
		for (File f : dirPath.listFiles()) {
			try {
				
				byte[] bytes = decrpyFile.decryptFileData(f.getAbsolutePath());
				
				System.out.println("dirPath"+ bytes.length);
				
				FileData data = new FileData();
				data.setData(bytes);
				data.setFilename(f.getName());
				int i = f.getName().lastIndexOf('.');
				if (i > 0) {
					data.setFileExtension(f.getName().substring(i+1));
				}
				
				lstFileData.add(data);

			} catch (Exception e) {
				System.out.println("Error While reading file ..." + e);
			}
		}
		//------------------------------
		
		FileListAdapter adapter=new FileListAdapter(lstFileData,ServerActivityEncryption.this);			
		lstFiles.setAdapter(adapter);
		//adapter.notifyDataSetChanged();
		
		sendButton.setOnClickListener(new OnClickListener() {
			public void onClick(View view) {
				new SendDataAsyncTask().execute();
			}
		});
		
		Intent discoverableIntent = new Intent(
				BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
		startActivityForResult(discoverableIntent, DISCOVERABLE_REQUEST_CODE);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		android.util.Log.e("TrackingFlow",
				"Creating thread to start listening...");
		new ConnectClientAsyncTask().execute(); 

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (socket != null) {
			try {
				os.close();
				socket.close();
			} catch (Exception e) {
			}
		}
	}


	private class ConnectClientAsyncTask extends AsyncTask<Void, Void, Boolean>{

		@Override
		protected Boolean doInBackground(Void... params) {
			boolean result = false;
			BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
			UUID uuid = UUID.fromString("4e5d48e0-75df-11e3-981f-0800200c9a66");
			try {
				BluetoothServerSocket serverSocket = adapter
						.listenUsingRfcommWithServiceRecord("BLTServer", uuid);
				android.util.Log.e("TrackingFlow", "Listening...");
				socket = serverSocket.accept();

				android.util.Log.e("TrackingFlow", "Socket accepted...");
				os = socket.getOutputStream();
				
				result= true;
				
			} catch (IOException e) {
				android.util.Log.e("TrackingFlow", "Error"+e);
				result = false;				
			}
			
			return result;
		}
		@Override
		protected void onPostExecute(Boolean result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			if(result){
				Toast.makeText(getApplicationContext(),						
						"Device "+ socket.getRemoteDevice().getName() +" connected successfully.", Toast.LENGTH_SHORT).show();
				sendButton.setEnabled(true);
				
			}else{				
				Toast.makeText(getApplicationContext(),
						"Device disconnected...", Toast.LENGTH_SHORT).show();
			}
			
		}
		
	}
	
	private class SendDataAsyncTask extends AsyncTask<Void, Void, Integer> {
		
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			progressBar.setVisibility(View.VISIBLE);
		}

		@Override
		protected Integer doInBackground(Void... params) {
			List<FileData> lstFileData = new ArrayList<FileData>();
			try {

				File[] file = Environment.getExternalStoragePublicDirectory(
						Environment.DIRECTORY_DOWNLOADS).listFiles();
				
				long startTime = System.currentTimeMillis();
				
				for (File f : file) {
					
					byte[] bytes = new byte[(int) f.length()];
					BufferedInputStream bis;
					bis = new BufferedInputStream(new FileInputStream(f));
					bis.read(bytes, 0, bytes.length);					
					System.out.println("Data " + bytes.length);
					FileData data = new FileData();
					data.setData(bytes);
					data.setFilename(f.getName());
					lstFileData.add(data);
					bis.close();

				}
				long endTime = System.currentTimeMillis();
				System.out.println("add in list " + (endTime - startTime));
				
				long startTime1 = System.currentTimeMillis();
				
				for(FileData d : lstFileData ){
					System.out.println("File Name " + d.getFilename());
				}
				
				byte[] byteArr = covertObjectIntoStreamOfBytes(lstFileData);
				writeChunk(byteArr,1024*8);
				
				long endTime1 = System.currentTimeMillis();
				System.out.println("add in list d " + (endTime1 - startTime1));

			} catch (IOException e) {
				System.out.println("Error " + e);
				progressBar.setVisibility(View.GONE);
			}

			return lstFileData.size();
		}

		/***
		 * Convert Object into stream of bytes
		 * 
		 * @param obj
		 * @return
		 * @throws IOException
		 */
		public byte[] covertObjectIntoStreamOfBytes(Object obj) throws IOException {
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(
					byteArrayOutputStream);
			objectOutputStream.writeObject(obj);
			objectOutputStream.flush();
			return byteArrayOutputStream.toByteArray();
		}
		
		/***
		 * Create Chunks of bytes array and write it in output stream...
		 * 
		 * @param source
		 * @param chunksize
		 */
		void writeChunk(byte[] source, int chunksize) {

			int start = 0;
			System.out.println("total Chunk "+source.length);
			
			while (start < source.length) {
				int end = Math.min(source.length, start + chunksize);
				try {
					
					os.write(Arrays.copyOfRange(source, start, end));
				} catch (IOException e) {
					
				}
				start = end;
				System.out.println("Start "+start+"end "+end);
			}
			try {
				os.write("done".toString().getBytes());
				os.flush();
			} catch (IOException e) {
				
			}

		}


		@Override
		protected void onPostExecute(Integer result) {
			super.onPostExecute(result);
			progressBar.setVisibility(View.GONE);
			Toast.makeText(getBaseContext(), String.valueOf(result)+" files send to device "+socket.getRemoteDevice().getBondState()+" successfully." ,
					Toast.LENGTH_SHORT).show();
			sendButton.setEnabled(false);
			
			android.util.Log.e("TrackingFlow",
					"Creating thread to start listening...");
			new ConnectClientAsyncTask().execute(); 

		}
	}

}
