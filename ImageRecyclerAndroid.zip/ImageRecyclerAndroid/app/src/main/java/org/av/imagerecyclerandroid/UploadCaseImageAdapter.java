package org.av.imagerecyclerandroid;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by abhishekv on 9/21/2015.
 */
public class UploadCaseImageAdapter extends RecyclerView.Adapter<UploadCaseImageAdapter.UploadViewHolder> {

    /**
     * Stores path of the all images related to particular case.
     */

    ArrayList listOfData;
    private MainActivity createCaseScreenActivity;
    private int requiredWidth;
    private int requiredHeight;


    public UploadCaseImageAdapter(ArrayList listOfData, MainActivity createCaseScreenActivity, int requiredWidth) {
        this.listOfData = listOfData;
        this.createCaseScreenActivity = createCaseScreenActivity;

        this.requiredWidth = requiredWidth / 3 - 100;
        this.requiredHeight = this.requiredWidth;
    }

    @Override
    public UploadViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.custom_row_layout, viewGroup, false);
        // set the view's size, margins, paddings and layout parameters

        return new UploadViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final UploadViewHolder holder, final int position) {
        HashMap mapOfData= (HashMap) listOfData.get(position);
        String name=(String)mapOfData.get("PatientName");

       final ArrayList<String> imagePathList=(ArrayList)mapOfData.get("ImagePath");


        holder.patientName.setText(name);
        ImageGridAdapter imageGridAdapter=new ImageGridAdapter(mapOfData,createCaseScreenActivity,requiredWidth,position);
        holder.imageGrid.setAdapter(imageGridAdapter);
        imageGridAdapter.notifyDataSetChanged();
        holder.imageGrid.post(new Runnable() {
            @Override
            public void run() {
                int totalChild = imagePathList.size();
                int noOfRows = totalChild / 3 + (totalChild % 3 > 0 ? 1 : 0);
             //   Log.d("Post","No Of rows "+noOfRows+" Total no of child "+totalChild);
                View view = holder.imageGrid.getChildAt(0);
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,noOfRows * view.getMeasuredHeight());
                holder.imageGrid.setLayoutParams(lp);
            }
        });

        Log.d("UPload Adapter","PAtient Name "+name);
    }


    @Override
    public int getItemCount() {
        return listOfData.size();
    }

    public static class UploadViewHolder extends RecyclerView.ViewHolder {
        public LinearLayout rootView;
        public TextView patientName;
        public GridView imageGrid;

        public UploadViewHolder(View itemView) {
            super(itemView);
            rootView = (LinearLayout) itemView;
            patientName = (TextView) rootView.findViewById(R.id.patientName);
            imageGrid = (GridView) rootView.findViewById(R.id.imageGrid);
        }
    }


}
