package org.av.imagerecyclerandroid;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by abhishekv on 9/23/2015.
 */
public class ImageGridAdapter extends BaseAdapter {

    private MainActivity mainActivity;
    private HashMap mapOfData;
    private ArrayList<Integer> imagePath;
    private int requiredSize;
    private int parentRowId;
    private ArrayList<String> selectedArrayList;

    public ImageGridAdapter(HashMap mapOfData, MainActivity mainActivity, int requiredSize, int parentRowId) {

        this.mainActivity = mainActivity;
        this.requiredSize = requiredSize;
        this.parentRowId = parentRowId;
        this.mapOfData = mapOfData;
        this.imagePath = (ArrayList) mapOfData.get("ImagePath");

    }

    @Override
    public int getCount() {
        return imagePath.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int i, View view, ViewGroup viewGroup) {
       final Holder holder = new Holder();
        final View rowView;

        LayoutInflater inflater = (LayoutInflater) mainActivity.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        rowView = inflater.inflate(R.layout.custom_grid_layout, null,false);
        holder.imageView = (ImageView) rowView.findViewById(R.id.imageHolder);
        holder.checkbox=(ImageView) rowView.findViewById(R.id.checkbox);
        if (mainActivity.sparseIntArray.containsKey(parentRowId)) {
            selectedArrayList = mainActivity.sparseIntArray.get(parentRowId);
            if (selectedArrayList.contains(String.valueOf(i))) {
                holder.checkbox.setVisibility(View.VISIBLE);
            }
            else
            {
                holder.checkbox.setVisibility(View.GONE);
            }
        }
        if (mainActivity.getBitmapFromMemCache(imagePath.get(i) + "_" + mapOfData.get("PatientName")) != null) {
            Bitmap bitmap = mainActivity.getBitmapFromMemCache(imagePath.get(i) + "_" + mapOfData.get("PatientName"));
            holder.imageView.setImageBitmap(bitmap);
            Log.d("GridView",i +"_"+mapOfData.get("PatientName")+" loaded from cached");
        } else {
            loadImageIntoImageView(imagePath.get(i), holder.imageView);
            Log.d("GridView", i + "_" + mapOfData.get("PatientName") + " Added to cached");
        }

        rowView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mainActivity.sparseIntArray.containsKey(parentRowId)) {

                    selectedArrayList = mainActivity.sparseIntArray.get(parentRowId);
                    if (selectedArrayList.contains(String.valueOf(i))) {
                        selectedArrayList.remove(String.valueOf(i));
                        holder.checkbox.setVisibility(View.GONE);
                    } else {
                        selectedArrayList.add(String.valueOf(i));
                        holder.checkbox.setVisibility(View.VISIBLE);
                    }
                    mainActivity.sparseIntArray.put(parentRowId, selectedArrayList);
                } else {
                    selectedArrayList = new ArrayList<String>();
                    selectedArrayList.add(String.valueOf(i));
                    holder.checkbox.setVisibility(View.VISIBLE);
                    mainActivity.sparseIntArray.put(parentRowId, selectedArrayList);
                }

            }
        });
        return rowView;
    }

    public void loadImageIntoImageView(int filePath, final ImageView patientDetailImageView) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(mainActivity.getResources(), filePath, options);
        //BitmapFactory.decodeFile(filePath, options);
        int bitmapWidth = options.outWidth;
        int bitmapHeight = options.outHeight;


        int inSampleSize = 1;
        requiredSize=100;
        if (bitmapHeight > requiredSize || bitmapWidth > requiredSize) {

             int halfHeight = bitmapHeight / 2;
             int halfWidth = bitmapWidth / 2;

            while ((halfHeight/inSampleSize ) > requiredSize
                    && (halfWidth/inSampleSize) > requiredSize) {
                inSampleSize *= 2;
            }
        }
        Log.d(this.getClass().getSimpleName(), "In Sample Size " + inSampleSize);
        options.inSampleSize = inSampleSize;
        options.inJustDecodeBounds = false;
        Bitmap bitmap = BitmapFactory.decodeResource(mainActivity.getResources(), filePath, options);
        mainActivity.addBitmapToMemoryCache(filePath + "_" + mapOfData.get("PatientName"), bitmap);

        patientDetailImageView.setImageBitmap(bitmap);

    }

    class Holder {
        ImageView imageView,checkbox;
    }
}
